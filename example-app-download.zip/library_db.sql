-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2024 at 07:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `isbn` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `published` date NOT NULL,
  `image` varchar(255) NOT NULL,
  `num_available` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `created_at`, `updated_at`, `title`, `author`, `genre`, `description`, `isbn`, `publisher`, `published`, `image`, `num_available`) VALUES
(1, '2024-07-30 20:45:55', '2024-07-30 20:47:58', 'The Blade Itself', 'Joe Abercrombie', 'Fantasy', 'Logen Ninefingers, infamous barbarian, has finally run out of luck. Caught in one feud too many, he’s on the verge of becoming a dead barbarian – leaving nothing behind him but bad songs, dead friends, and a lot of happy enemies.<br><br>\r\nNobleman Captain Jezal dan Luthar, dashing officer, and paragon of selfishness, has nothing more dangerous in mind than fleecing his friends at cards and dreaming of glory in the fencing circle. But war is brewing, and on the battlefields of the frozen North they fight by altogether bloodier rules.<br><br>\r\nInquisitor Glokta, cripple turned torturer, would like nothing better than to see Jezal come home in a box. But then Glokta hates everyone: cutting treason out of the Union one confession at a time leaves little room for friendship. His latest trail of corpses may lead him right to the rotten heart of government, if he can stay alive long enough to follow it.<br><br>\r\nEnter the wizard, Bayaz. A bald old man with a terrible temper and a pathetic assistant, he could be the First of the Magi, he could be a spectacular fraud, but whatever he is, he\'s about to make the lives of Logen, Jezal, and Glokta a whole lot more difficult.<br><br>\r\nMurderous conspiracies rise to the surface, old scores are ready to be settled, and the line between hero and villain is sharp enough to draw blood.', '978-0-316-38731-6', 'Orbit Books', '2006-05-04', '1722357954_blade.jpg', 10),
(2, '2024-07-30 20:47:40', '2024-07-30 20:48:13', 'Before They Are Hanged', 'Joe Abercrombie', 'Fantasy', 'Superior Glokta has a problem. How do you defend a city surrounded by enemies and riddled with traitors, when your allies can by no means be trusted, and your predecessor vanished without a trace? It’s enough to make a torturer want to run – if he could even walk without a stick.<br><br>\r\nNorthmen have spilled over the border of Angland and are spreading fire and death across the frozen country. Crown Prince Ladisla is poised to drive them back and win undying glory. There is only one problem – he commands the worst-armed, worst-trained, worst-led army in the world.<br><br>\r\nAnd Bayaz, the First of the Magi, is leading a party of bold adventurers on a perilous mission through the ruins of the past. The most hated woman in the South, the most feared man in the North, and the most selfish boy in the Union make a strange alliance, but a deadly one. They might even stand a chance of saving mankind from the Eaters. If they didn’t hate each other quite so much.<br><br>\r\nAncient secrets will be uncovered. Bloody battles will be won and lost. Bitter enemies will be forgiven – but not before they are hanged.', '978-0-316-38735-4', 'Orbit Books', '2007-03-15', '1722358060_hanged.jpg', 10),
(3, '2024-07-30 20:49:51', '2024-07-30 20:49:51', 'Last Argument of Kings', 'Joe Abercrombie', 'Fantasy', 'The end is coming. Logen Ninefingers might only have one more fight in him but it\'s going to be a big one. Battle rages across the North, the King of the Northmen still stands firm, and there\'s only one man who can stop him. His oldest friend, and his oldest enemy. It\'s past time for the Bloody-Nine to come home.<br><br>\r\nWith too many masters and too little time, Superior Glokta is fighting a different kind of war. A secret struggle in which no one is safe, and no one can be trusted. His days with a sword are far behind him. It\'s a good thing blackmail, threats and torture still work well enough.<br><br>\r\nJezal dan Luthar has decided that winning glory is far too painful, and turned his back on soldiering for a simple life with the woman he loves. But love can be painful too, and glory has a nasty habit of creeping up on a man when he least expects it.<br><br>\r\nWhile the King of the Union lies on his deathbead, the peasants revolt and the nobles scramble to steal his crown. No one believes that the shadow of war is falling across the very heart of the Union. The First of the Magi has a plan to save the world, as he always does. But there are risks. There is no risk more terrible, after all, than to break the First Law...', '978-0-316-38740-8', 'Orbit Books', '2008-03-20', '1722358191_kings.jpg', 10),
(4, '2024-07-30 20:53:14', '2024-07-30 20:53:14', 'A Game of Thrones', 'George R. R. Martin', 'Fantasy', 'Long ago, in a time forgotten, a preternatural event threw the seasons out of balance. In a land where summers can last decades and winters a lifetime, trouble is brewing. The cold is returning, and in the frozen wastes to the north of Winterfell, sinister forces are massing beyond the kingdom’s protective Wall. To the south, the king’s powers are failing—his most trusted adviser dead under mysterious circumstances and his enemies emerging from the shadows of the throne. At the center of the conflict lie the Starks of Winterfell, a family as harsh and unyielding as the frozen land they were born to. Now Lord Eddard Stark is reluctantly summoned to serve as the king’s new Hand, an appointment that threatens to sunder not only his family but the kingdom itself.\r\n<br><br>\r\nSweeping from a harsh land of cold to a summertime kingdom of epicurean plenty, A Game of Thrones tells a tale of lords and ladies, soldiers and sorcerers, assassins and bastards, who come together in a time of grim omens. Here an enigmatic band of warriors bear swords of no human metal; a tribe of fierce wildlings carry men off into madness; a cruel young dragon prince barters his sister to win back his throne; a child is lost in the twilight between life and death; and a determined woman undertakes a treacherous journey to protect all she holds dear. Amid plots and counter-plots, tragedy and betrayal, victory and terror, allies and enemies, the fate of the Starks hangs perilously in the balance, as each side endeavors to win that deadliest of conflicts: the game of thrones.', '978-0-553-57340-4', 'Bantam Books', '1996-08-06', '1722358394_thrones.jpg', 10),
(5, '2024-07-30 20:54:50', '2024-07-30 20:54:50', 'A Clash of Kings', 'George R. R. Martin', 'Fantasy', 'A comet the color of blood and flame cuts across the sky. Two great leaders—Lord Eddard Stark and Robert Baratheon—who hold sway over an age of enforced peace are dead, victims of royal treachery. Now, from the ancient citadel of Dragonstone to the forbidding shores of Winterfell, chaos reigns. Six factions struggle for control of a divided land and the Iron Throne of the Seven Kingdoms, preparing to stake their claims through tempest, turmoil, and war.\r\n<br><br>\r\nIt is a tale in which brother plots against brother and the dead rise to walk in the night. Here a princess masquerades as an orphan boy; a knight of the mind prepares a poison for a treacherous sorceress; and wild men descend from the Mountains of the Moon to ravage the countryside. Against a backdrop of incest and fratricide, alchemy and murder, victory may go to the men and women possessed of the coldest steel...and the coldest hearts. For when kings clash, the whole land trembles.\r\n<br><br>\r\nHere is the second volume in George R.R. Martin magnificent cycle of novels that includes A Game of Thrones and A Storm of Swords. As a whole, this series comprises a genuine masterpiece of modern fantasy, bringing together the best the genre has to offer. Magic, mystery, intrigue, romance, and adventure fill these pages and transport us to a world unlike any we have ever experienced. Already hailed as a classic, George R.R. Martin stunning series is destined to stand as one of the great achievements of imaginative fiction.', '978-0-553-57990-1', 'Bantam Books', '1998-11-16', '1722358490_clash.jpg', 10),
(6, '2024-07-30 20:56:57', '2024-07-30 20:56:57', 'A Storm of Swords', 'George R. R. Martin', 'Fantasy', 'Here is the third volume in George R.R. Martin\'s magnificent cycle of novels that includes A Game of Thrones and A Clash of Kings. Together, this series comprises a genuine masterpiece of modern fantasy, destined to stand as one of the great achievements of imaginative fiction.\r\n<br><br>\r\nOf the five contenders for power, one is dead, another in disfavor, and still the wars rage as alliances are made and broken. Joffrey sits on the Iron Throne, the uneasy ruler of the Seven Kingdoms. His most bitter rival, Lord Stannis, stands defeated and disgraced, victim of the sorceress who holds him in her thrall. Young Robb still rules the North from the fortress of Riverrun. Meanwhile, making her way across a blood-drenched continent is the exiled queen, Daenerys, mistress of the only three dragons still left in the world. And as opposing forces manoeuver for the final showdown, an army of barbaric wildlings arrives from the outermost limits of civilization, accompanied by a horde of mythical Others—a supernatural army of the living dead whose animated corpses are unstoppable. As the future of the land hangs in the balance, no one will rest until the Seven Kingdoms have exploded in a veritable storm of swords...', '978-0-553-57342-8', 'Bantam Books', '2000-08-08', '1722358617_swords.jpg', 10),
(7, '2024-07-30 20:58:18', '2024-07-30 20:58:18', 'A Feast for Crows', 'George R. R. Martin', 'Fantasy', 'Crows will fight over a dead man\'s flesh, and kill each other for his eyes.\r\n<br><br>\r\nBloodthirsty, treacherous and cunning, the Lannisters are in power on the Iron Throne in the name of the boy-king Tommen. The war in the Seven Kingdoms has burned itself out, but in its bitter aftermath new conflicts spark to life.\r\n<br><br>\r\nThe Martells of Dorne and the Starks of Winterfell seek vengeance for their dead. Euron Crow\'s Eye, as black a pirate as ever raised a sail, returns from the smoking ruins of Valyria to claim the Iron Isles. From the icy north, where Others threaten the Wall, apprentice Maester Samwell Tarly brings a mysterious babe in arms to the Citadel.\r\n<br><br>\r\nAgainst a backdrop of incest and fratricide, alchemy and murder, victory will go to the men and women possessed of the coldest steel and the coldest hearts.', '978-0-553-58202-4', 'Bantam Books', '2005-10-17', '1722358698_crows.jpg', 10),
(8, '2024-07-30 21:00:12', '2024-07-30 21:00:12', 'A Dance with Dragons', 'George R. R. Martin', 'Fantasy', 'In the aftermath of a colossal battle, the future of the Seven Kingdoms hangs in the balance—beset by newly emerging threats from every direction. In the east, Daenerys Targaryen, the last scion of House Targaryen, rules with her three dragons as queen of a city built on dust and death. But Daenerys has thousands of enemies, and many have set out to find her. As they gather, one young man embarks upon his own quest for the queen, with an entirely different goal in mind.\r\n<br><br>\r\nFleeing from Westeros with a price on his head, Tyrion Lannister, too, is making his way to Daenerys. But his newest allies in this quest are not the rag-tag band they seem, and at their heart lies one who could undo Daenerys’s claim to Westeros forever.\r\n<br><br>\r\nMeanwhile, to the north lies the mammoth Wall of ice and stone—a structure only as strong as those guarding it. There, Jon Snow, 998th Lord Commander of the Night’s Watch, will face his greatest challenge. For he has powerful foes not only within the Watch but also beyond, in the land of the creatures of ice.\r\n<br><br>\r\nFrom all corners, bitter conflicts reignite, intimate betrayals are perpetrated, and a grand cast of outlaws and priests, soldiers and skinchangers, nobles and slaves, will face seemingly insurmountable obstacles. Some will fail, others will grow in the strength of darkness. But in a time of rising restlessness, the tides of destiny and politics will lead inevitably to the greatest dance of all.', '978-0-006-48611-4', 'Bantam Books', '2011-07-12', '1722358812_dance.jpg', 10),
(9, '2024-07-30 21:02:14', '2024-07-30 21:02:14', 'Dune', 'Frank Herbert', 'Science Fiction', 'Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the “spice” melange, a drug capable of extending life and enhancing consciousness. Coveted across the known universe, melange is a prize worth killing for...\r\n<br><br>\r\nWhen House Atreides is betrayed, the destruction of Paul’s family will set the boy on a journey toward a destiny greater than he could ever have imagined. And as he evolves into the mysterious man known as Muad’Dib, he will bring to fruition humankind’s most ancient and unattainable dream.', '978-0-593-09932-2', 'Ace Books', '1965-06-01', '1722358934_dune.jpg', 10),
(10, '2024-07-30 21:09:38', '2024-07-30 21:09:38', 'The Fellowship of the Ring', 'J.R.R. Tolkien', 'Fantasy', 'One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.\r\n<br><br>\r\nIn ancient times the Rings of Power were crafted by the Elven-smiths, and Sauron, the Dark Lord, forged the One Ring, filling it with his own power so that he could rule all others. But the One Ring was taken from him, and though he sought it throughout Middle-earth, it remained lost to him. After many ages it fell into the hands of Bilbo Baggins, as told in The Hobbit.\r\n<br><br>\r\nIn a sleepy village in the Shire, young Frodo Baggins finds himself faced with an immense task, as his elderly cousin Bilbo entrusts the Ring to his care. Frodo must leave his home and make a perilous journey across Middle-earth to the Cracks of Doom, there to destroy the Ring and foil the Dark Lord in his evil purpose.', '978-0-358-38023-8', 'Clarion Books', '1954-07-29', '1722359377_fellowship.jpg', 10),
(11, '2024-07-30 21:11:20', '2024-07-30 21:11:20', 'The Two Towers', 'J.R.R. Tolkien', 'Fantasy', 'One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.\r\n<br><br>\r\nJ.R.R. Tolkien’s classic epic fantasy trilogy The Lord of the Rings, now with a fresh new package for Book 2, The Two Towers.\r\n<br><br>\r\nFrodo and his Companions of the Ring have been beset by danger during their quest to prevent the Ruling Ring from falling into the hands of the Dark Lord by destroying it in the Cracks of Doom. They lost the wizard Gandalf in the Mines of Moria. And Boromir, seduced by the power of the Ring, tried to seize it by force. While Frodo and Sam made their escape, the rest of the company was attacked by Orcs.\r\n<br><br>\r\nNow they continue their journey alone down the great River Anduin—alone, that is, save for the mysterious creeping figure that follows wherever they go.', '978-0-358-38024-5', 'Clarion Books', '1954-11-11', '1722359480_two-towers.jpg', 10),
(12, '2024-07-30 21:13:13', '2024-07-30 21:13:13', 'The Return of the King', 'J.R.R. Tolkien', 'Fantasy', 'One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.\r\n<br><br>\r\nJ.R.R. Tolkien’s classic epic fantasy trilogy The Lord of the Rings, now with a fresh new package for Book 3, The Return of the King.\r\n<br><br>\r\nAs the Shadow of Mordor grows across the land, the Companions of the Ring have become involved in separate adventures. Aragorn, revealed as the hidden heir of the ancient Kings of the West, has joined with the Riders of Rohan against the forces of Isengard and takes part in the desperate victory of the Hornburg.\r\n<br><br>\r\nMerry and Pippin, captured by Orcs, escape into Fangorn Forest and there encounter the Ents. Gandalf has miraculously returned and defeated the evil wizard, Saruman. Sam has left his master for dead after a battle with the giant spider, Shelob; but Frodo is still alive—now in the foul hands of the Orcs. And all the while the armies of the Dark Lord are massing as the One Ring draws ever nearer to the Cracks of Doom.', '978-0-358-38025-2', 'Clarion Books', '1955-10-20', '1722359593_return-of-the-king.jpg', 10),
(13, '2024-07-30 21:16:34', '2024-07-30 21:16:34', 'The Sagas of Icelanders', 'Jane Smiley', 'History', 'A unique body of medieval literature, the Sagas rank with the world\'s greatest literary treasures--as epic as Homer, as deep in tragedy as Sophocles, as engagingly human as Shakespeare. Set around the turn of the last millennium, these stories depict with an astonishingly modern realism the lives and deeds of the Norse men and women who first settled Iceland and of their descendants, who ventured further west--to Greenland and, ultimately, the coast of North America itself.\r\n<br><br>\r\nThe ten Sagas and seven shorter tales in this volume include the celebrated \"Vinland Sagas,\" which recount Leif Eiriksson\'s pioneering voyage to the New World and contain the oldest descriptions of the North American continent.\r\n<br><br>\r\nFor more than seventy years, Penguin has been the leading publisher of classic literature in the English-speaking world. With more than 1,700 titles, Penguin Classics represents a global bookshelf of the best works throughout history and across genres and disciplines. Readers trust the series to provide authoritative texts enhanced by introductions and notes by distinguished scholars and contemporary authors, as well as up-to-date translations by award-winning translators.', '978-0-141-00003-9', 'Penguin Books', '2001-03-01', '1722359794_sagas.jpg', 5),
(14, '2024-07-30 21:18:49', '2024-07-30 21:18:49', 'The Last Kingdom', 'Bernard Cornwell', 'Historical Fiction', 'The first installment of Bernard Cornwell’s New York Times bestselling series chronicling the epic saga of the making of England, “like Game of Thrones, but real” (The Observer, London)—the basis for The Last Kingdom, the hit Netflix series.\r\n<br><br>\r\nIn the middle years of the ninth century, the fierce Danes stormed onto British soil, hungry for spoils and conquest. Kingdom after kingdom fell to the ruthless invaders until but one realm remained. And suddenly the fate of all England—and the course of history—depended upon one man, one king.\r\n<br><br>\r\nFrom New York Times bestselling storyteller Bernard Cornwell comes a rousing epic adventure of courage, treachery, duty, devotion, majesty, love, and battle as seen through the eyes of a young warrior who straddled two worlds.', '978-0-060-88718-6', 'HarperCollins', '2006-01-03', '1722359929_last-kingdom.jpg', 10),
(15, '2024-07-30 21:29:54', '2024-07-30 21:29:54', 'The Pale Horseman', 'Bernard Cornwell', 'Historical Fiction', 'The second installment of Bernard Cornwell\'s New York Times bestselling series chronicling the epic saga of the making of England, \"like Game of Thrones, but real\" (The Observer, London)--the basis for The Last Kingdom, the hit television series.\r\n<br><br>\r\nAs the last unvanquished piece of England, Wessex is eyed hungrily by the fearsome Viking conquerors. Uhtred, a dispossessed young nobleman, is tied to the imperiled land by birth and marriage but was raised by the Danish invaders--and he questions where his allegiance must lie. But blood is his destiny, and when the overwhelming Viking horde attacks out of a wintry darkness, Uhtred must put aside all hatred and distrust and stand beside his embattled country\'s staunch defender--the fugitive King Alfred.\r\n<br><br>\r\nThe Pale Horseman is a gripping, monumental adventure that gives breathtaking life to one of the most important epochs in English history--yet another masterwork from New York Times bestselling author Bernard Cornwell.', '978-0-061-14483-7', 'HarperCollins', '2007-01-01', '1722360594_pale-horseman.jpg', 10),
(16, '2024-07-30 21:33:02', '2024-07-30 21:33:02', 'Heir to the Empire', 'Timothy Zahn', 'Science Fiction', 'It\'s five years after Return of the Jedi: the Rebel Alliance has destroyed the Death Star, defeated Darth Vader and the Emperor, and drove the remnants of the old Imperial Starfleet to a distant corner of the galaxy. Princess Leia and Han Solo are married and expecting Jedi twins. And Luke Skywalker has become the first in a long-awaited line of Jedi Knights.\r\n<br><br>\r\nBut thousands of light-years away, the last of the Emperor’s warlords, has taken command of the shattered Imperial fleet, readied it for war, and pointed it at the fragile heart of the new Republic. For this dark warrior has made two vital discoveries that could destroy everything the courageous men and women of the Rebel Alliance fought so hard to build. The explosive confrontation that results is a towering epic of action, invention, mystery, and spectacle on a galactic scale-in short, a story worthy of the name Star Wars.', '978-0-553-29612-9', 'Del Rey', '1992-05-01', '1722360782_heir.jpg', 10),
(17, '2024-07-30 21:34:15', '2024-07-30 21:34:15', 'Dark Force Rising', 'Timothy Zahn', 'Science Fiction', 'The dying Empire’s most cunning and ruthless warlord, Grand Admiral Thrawn, has taken command of the remnants of the Imperial Fleet and launched a massive campaign aimed at the New Republic’s destruction. Meanwhile, Han Solo and Lando Calrissian race against time to find proof of treason inside the highest Republic Council—only to discover instead a ghostly fleet of warships that could bring doom to their friends and victory to their enemies.\r\n<br><br>\r\nYet most dangerous of all is a new Dark Jedi, risen from the ashes of a shrouded past, consumed by bitterness, and scheming to corrupt Luke Skywalker to the dark side.', '978-0-553-56071-8', 'Del Rey', '1993-02-01', '1722360855_dark-force.jpg', 10),
(18, '2024-07-30 21:39:08', '2024-07-30 21:39:08', 'The Last Command', 'Timothy Zahn', 'Science Fiction', 'The embattled Republic reels from the attacks of Grand Admiral Thrawn, who has marshaled the remnants of the Imperial forces and driven the Rebels back with an abominable technology recovered from the Emperor’s secret fortress: clone soldiers. As Thrawn mounts his final siege, Han Solo and Chewbacca struggle to form a coalition of smugglers for a last-ditch attack, while Princess Leia holds the Alliance together and prepares for the birth of her Jedi twins.\r\n<br><br>\r\nThe Republic has one last hope—sending a small force into the very stronghold that houses Thrawn’s terrible cloning machines. There a final danger awaits, as the Dark Jedi C’baoth directs the battle against the Rebels and builds his strength to finish what he already started: the destruction of Luke Skywalker.', '978-0-553-56492-1', 'HarperCollins', '1994-01-01', '1722361148_last-command.jpg', 10);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `holds`
--

CREATE TABLE `holds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `waiting` tinyint(1) NOT NULL,
  `book_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `book_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(146, '0001_01_01_000000_create_users_table', 1),
(147, '0001_01_01_000001_create_cache_table', 1),
(148, '0001_01_01_000002_create_jobs_table', 1),
(149, '2024_06_12_201138_create_books_table', 1),
(150, '2024_06_12_203232_create_wishlists_table', 1),
(151, '2024_06_12_203731_create_loans_table', 1),
(152, '2024_06_26_185316_create_holds_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('f5w1dexwL1ahSaL66c5K9T9ctYMZym1YpWZVKbap', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZzhHOFdET0Y5cFljcEdXR2FYc2RlV2JaV3dYcXlrYUFJb0w0d3RIeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9ib29rcz9zZWFyY2g9dGhlJnNvcnQ9YXNjIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9', 1722361183);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '2024-07-30 20:32:01', '$2y$12$jrRvyfRYe1/rObR0Luuvr.TG3RA71jfCASLKXzq3IS9kET2pf2lo.', 1, '4V4GfiWmxP', '2024-07-30 20:32:02', '2024-07-30 20:32:02');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `book_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `holds`
--
ALTER TABLE `holds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `holds_book_id_foreign` (`book_id`),
  ADD KEY `holds_user_id_foreign` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loans_book_id_foreign` (`book_id`),
  ADD KEY `loans_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wishlists_book_id_foreign` (`book_id`),
  ADD KEY `wishlists_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holds`
--
ALTER TABLE `holds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `holds`
--
ALTER TABLE `holds`
  ADD CONSTRAINT `holds_book_id_foreign` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `holds_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `loans_book_id_foreign` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `loans_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_book_id_foreign` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
